#include  <stdio.h>
#include  "bigint.h"
#include  <string.h>
#include  <time.h>
/* calculate the greatest common divisor of n and m,result stored in res */
void gcd(Int n[],Int m[],Int res[]){
	Int temp[MAXD+1]={0};
	Int x[MAXD+1]={0};
	Int y[MAXD+1]={0};
	int i=-1;

	mov(x,n);
	mov(y,m);
	while (i!=0){
		div(temp,x,y);
		if (sgn(Rem)==0){ /* x | y */
			mov(res,y);
			return;
		}else{
			mov(temp,Rem);
			mov(x,y);
			mov(y,temp);
		}
	}
}

Int ext_x[MAXD+1],ext_y[MAXD+1];
void ext_euclid(Int a[],Int b[],Int res[]){
	Int t[MAXD+1];
	Int d[MAXD+1];
	Int tmp[MAXD+1];

	if (sgn(b)==0){
		fillint(ext_x,1);
		fillint(ext_y,0);
		mov(res,a);
		return;
	}
	div(tmp,a,b);
	mov(tmp,Rem);
	ext_euclid(b,tmp,res);
	mov(t,ext_x);
	mov(ext_x,ext_y);/* ext_x=ext_y */
	div(tmp,a,b);
	mov(d,tmp);/* d=a/b */
	mul(tmp,d,ext_y);/* tmp=a/b*y */
	mov(d,tmp);/* d=a*b/y */
	mov(tmp,t);
	sub(tmp,d);
	mov(ext_y,tmp);/* y=t-a/b*y */
}


/* calculate (n^x)%m,result stored in res */
void fast_mod(Int n[],Int x[],Int m[],Int res[]){
	Int b[MAXD+1]={0};
	Int TWO[MAXD+1]={0};
	Int temp[MAXD+1]={0};
	Int N[MAXD+1]={0};
	Int M[MAXD+1]={0};
	Int X[MAXD+1]={0};

	fillint(b,1);/* b=1 */
	fillint(TWO,2);/* TWO=2 */
	mov(N,n);
	mov(M,m);
	mov(X,x);

	while (sgn(X)!=0){ /* while x!=0 */
		div(temp,X,TWO);
		if (sgn(Rem)!=0){ /* if (x%2)!=0 */
			/* b=(b*n)%m */
			mul(temp,N,b);
			mov(b,temp);
			div(temp,b,M);
			mov(b,Rem);
		}
		/* n=(n^2)%m */
		mul(temp,N,N);
		mov(N,temp);
		div(temp,N,M);
		mov(N,Rem);

		/* x/=2 */
		div(temp,X,TWO);
		mov(X,temp);
	}
	mov(res,b);
	return;
}

/* WITNESS function in the rabbin_miller */
int witness(Int a[],Int n[]){
	int i=0,k=0,t=0;
	Int j[MAXD+1];
	Int x[MAXD+1],tmp[MAXD+1],tmp2[MAXD+1];
	Int temp[MAXD+1];
	Int ONE[MAXD+1];
	Int TWO[MAXD+1];
	Int ZERO[MAXD+1];
	Int A[MAXD+1];
	Int N[MAXD+1];
	
	fillint(TWO,2);
	fillint(ONE,1);
	fillint(ZERO,0);
	mov(A,a);
	mov(N,n);

	mov(j,n);
	dec(j);

	div(tmp,j,TWO);
	while (compare(Rem,ZERO)==0){
		div(tmp,j,TWO);
		mov(j,tmp);
		t++;
		div(tmp,j,TWO);
	}
	fast_mod(A,j,N,x);

	mov(tmp2,n);
	dec(tmp2);
	for (i=1;i<=t;i++){
		/* tmp=x*x%n */
		mul(tmp,x,x);
		div(temp,tmp,N);
		mov(tmp,Rem);

		if (compare(tmp,ONE)==0 && compare(x,ONE)!=0 &&
				compare(x,tmp2)!=0)
			return 1;
		mov(x,tmp);
	}
	if (compare(x,ONE)!=0)
		return 1;
	return 0;

}

/* generate a random Int that has n decimal digit */
void random(Int to[],int n){
	int i=0,j=0,k=0;
	char buff[MAXD]={0};

	srand(time(NULL));

	while (buff[0]==0)
		buff[0]=rand()%10+'0';
	for (i=1;i<=n-1;i++){
		buff[i]=rand()%10+'0';
	}
	readInt_s(to,buff);
	return;
}

int miller_rabbin(Int n[]){
	int i=0,j=0,k=0;
	Int a[MAXD+1];
	Int r[MAXD+1];
	Int tmp[MAXD+1];

	Int ONE[MAXD+1];
	Int TWO[MAXD+1];
	Int ZERO[MAXD+1];

	fillint(ONE,1);
	fillint(TWO,2);
	fillint(ZERO,0);

	random(r,700);
	div(tmp,r,n);
	mov(a,Rem);
	inc(a);

	div(tmp,n,TWO);
	if (compare(Rem,ZERO)==0 && compare(n,TWO)!=0){
		return 0;
	}

	if (compare(n,TWO)==0)
		return 1;

	for (i=1;i<=5;i++){
		inc(a);
		div(tmp,a,n);
		mov(a,Rem);
		inc(a);
		
		div(tmp,n,a);
		if (compare(Rem,ZERO)==0){
			i--;
			continue;
		}
		if (witness(a,n))
			return 0;
	}
	return 1;
}


void generate_key(Int p[],Int q[],Int e[],Int d[],Int m[],int len){
	Int phi[MAXD+1];
	Int g[MAXD+1];
	Int ONE[MAXD+1];
	Int tmp1[MAXD+1],tmp2[MAXD+1];
	Int tmp3[MAXD+1],tmp4[MAXD+1];
	int f1=0,f2=0;

	fillint(ONE,1);
	mul(m,p,q);
	dec(p);
	dec(q);
	mul(phi,p,q);
	random(e,len);
	gcd(e,phi,g);

	while (compare(g,ONE)!=0){
		random(e,len);
		gcd(e,phi,g);
	}

	/* e*ext_x+phi*ext_y=1; */
	ext_euclid(e,phi,ONE);
	f1=sgn(ext_x);
	f2=sgn(ext_y);

	if (f1>0 && f2<0){
		mov(d,ext_x);
	}else if (f1<0 && f2>0){
		div(tmp1,ext_y,e);/* tmp1=ext_y/e */
		inc(tmp1);
		mov(tmp2,Rem);/* ext_y=e-ext_y%e */
		mov(tmp3,e);
		sub(tmp3,tmp2);/* tmp3=e-ext_y%e */
		
		mul(tmp2,phi,tmp1);/* tmp2=phi*tmp1 */
		add(ext_x,tmp2);
		mov(d,ext_x);
	}

}

void generate_prime(Int to[]){
	random(to,600);
	while (miller_rabbin(to)==0){
		random(to,600);
	}
}

/* convert buff to code */
int encode(char buff[],char code[],int len){
	int c=0,i=0,k=0,index=0;
	char ch,tmp[8];

	for (i=0;i<len;i++){
		ch=buff[i];
		k=0;
		while (ch){
			tmp[k++]=ch%10+'0';
			ch/=10;
		}
		while (k!=3){
			tmp[k]='0';
			k++;
		}
		while (k--){
			code[index++]=tmp[k];
		}
	}
	return index;
}

void encrypt(char code[],char dest[],int len,Int e[],Int m[]){
	Int x[MAXD+1];
	Int res[MAXD+1];
	readInt_s(x,code);

	fast_mod(x,e,m,res);
	to_char_array(res,dest);
}

void decrypt(char code[],char dest[],int len,Int e[],Int m[]){
	Int x[MAXD+1];
	Int res[MAXD+1];
	char tmp[1024];
	int ilen=0,i=0,k=0;
	readInt_s(x,code);

	memset(dest,0,1024);
	memset(tmp,0,sizeof(tmp));

	fast_mod(x,e,m,res);
	to_char_array(res,tmp);
	ilen=strlen(tmp);
	i=(3-ilen%3)%3;
	while (i--){
		dest[k++]='0';
	}
	for (i=0;i<ilen;i++){
		dest[k++]=tmp[i];
	}
}

