#include  <stdio.h>
#include  <string.h>
#include  <time.h>
#include  "bigint.h"
#include "basic_algorithm.h"

int main(int argc, char *argv[])
{
	int i=0,j=0,k=0;
	char opt[256]={0};
	FILE *fkey;
	Int e[MAXD+1];
	Int m[MAXD+1];	
	Int p[MAXD+1];
	Int q[MAXD+1];
	Int d[MAXD+1];



	init_char_set("0123456789");
	opt['-']=opt['+']=opt['*']=opt['/']=1;

	random(p,16);
	while (miller_rabbin(p)==0)
		random(p,16);
	sleep(1);
	random(q,15);
	while (miller_rabbin(q)==0)
		random(q,15);
	generate_key(p,q,e,d,m,16);
	fkey=freopen("public_key","w+",stdout);
	show(m);
	printf("\n");
	show(e);
	printf("\n");
	fclose(fkey);
	fkey=freopen("private_key","w+",stdout);
	show(m);
	printf("\n");
	show(d);
	printf("\n");
	fclose(fkey);

	return 0;
}

