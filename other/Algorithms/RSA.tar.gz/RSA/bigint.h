/*
MAXD the number of digits in every BigInt
BASE the BASE of the BigInt number usually 10, 16
LOG_BASE = Ceil(log(2,BASE)); for fast division operation
*/
#ifndef BIGING_H
	#define  BIGINT_H
#define MAXD 1500
#define BASE 10
#define LOG_BASE 4
/*The unit used as digit must have range larger than BASE*(BASE+1)*/
typedef unsigned char Int;
char char_buffer[MAXD+2];
/*The charset used to represent the number
  usually use 0123456789 or 0123456789abcdef
*/
char char_num[BASE];
/*A table denote which char is used as number*/
//char char_set[256]={0};
/*initialize charset and numset
  return 1 for init success
  return 0 for init failed, using default 0123456789
*/
int init_char_set(char* s);

/*fill zero*/
void empty(Int* to);

/*MOV to,from*/
void mov(Int* to,Int* from);

/*NEG to*/
void neg(Int* to);

/*INC to, return overflow flag*/
int inc(Int* to);

/*SGN to, return 0 for value is 0, otherwise return 1 for to>0, -1 for to<0*/
int sgn(Int* to);

/*read an Int from a string start from s, return pointor after reading*/
char* readInt_s(Int* to,char* s);

/*read an Int from stdin, return last char after reading*/
char readInt(Int *to);

/*fill a real int into Int*/
void fillint(Int* to,int num);

/*ADD to,from (return carry)*/
Int add(Int* to,Int* from);

/*SUB to,from (return carry)*/
Int sub(Int* to,Int* from);

/*MUL a,b (store in to)*/
void mul(Int* to,Int* a,Int* b);

/*remainder of the division*/
Int Rem[MAXD+1];
/*trying divider 1,2,4,8,...*/
Int Try[LOG_BASE][MAXD+1];
/*check if i*BASE^p less than Rem,max is the highest digit that scanned*/
int check(Int* i,int p,int max);

/*reduce i*BASE^p from Rem,max is the highest digit that scanned*/
void reduce(Int* i,int p,int max);

/*DIV a/b (Result in to,remainder in Rem,return true for divide by 0)*/
int div(Int* to,Int* a,Int* b);

/*show Int based BASE*/
void show(Int* to);
#endif
