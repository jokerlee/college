#ifndef BASIC_ALGORITHM_H
	#define  BASIC_ALGORITHM_H
	void gcd(Int n[],Int m[],Int res[]);
	void fase_mod(Int n[],Int x[],Int m[],Int res[]);
	int witness(Int a[],Int n[]);
	void random(Int to[],int n);
	int miller_rabbin(Int n[]);
	void generate_key(Int p[],Int q[],Int e[],Int d[],Int m[],int len);
	void generate_prime(Int to[]);
	int encode(char buff[],char code[],int len);
	void decrypt(char code[],char dest[],int len,Int e[],Int m[]);
	void encrypt(char code[],char dest[],int len,int e[],Int m[]);
#endif
