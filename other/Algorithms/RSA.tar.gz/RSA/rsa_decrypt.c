#include <stdio.h>
#include  <string.h>
#include "bigint.h"
#include "basic_algorithm.h"
int main(int argc, char *argv[])
{
	int i=0,j=0,k=0;
	int filelen=0,chunk_len=0;
	char buff1[1024],buff2[1024],code[1024];
	char buff_e[2048],buff_m[2048],buff_d[2048];
	char ch;
	int count=0,index=0,tmp=0;

	char opt[256]={0};
	FILE *fin,*fout;
	FILE *fkey;

	Int e[MAXD+1];
	Int m[MAXD+1];
	
	Int p[MAXD+1];
	Int q[MAXD+1];
	Int d[MAXD+1];



	init_char_set("0123456789");
	opt['-']=opt['+']=opt['*']=opt['/']=1;

	if (argc<2){
		printf("usage: RSA_decrypt [input_file] [output_file]\n");
		return 0;
	}

	fin=fopen(argv[1],"rb");
	if (fin==NULL){
		printf("input file open error,quit\n");
		return 0;
	}
	fout=fopen(argv[2],"w+b");
	if (fout==NULL){
		printf("output file create error,quit\n");
		return 0;
	}

	fkey=freopen("private_key","r",stdin);
	readInt(m);
	readInt(d);
	fclose(fkey);

	chunk_len=32;
	fseek(fin,0,SEEK_END);
	filelen=ftell(fin);
	fseek(fin,0,SEEK_SET);
	k=filelen/chunk_len+(filelen%chunk_len!=0);
	printf("start decrypting %d chunk(s)...\n",k);
	
	for (i=0;i<k;i++){
		memset(buff1,0,sizeof(buff1));
		fread(buff1,1,chunk_len,fin);
		j=chunk_len;
		memset(buff2,0,sizeof(buff2));
		decrypt(buff1,buff2,j,d,m);
		j=strlen(buff2);
		index=0;
		while (index<j){
			ch=0;
			for (tmp=0;tmp<3;tmp++){
				ch=ch*10+buff2[index]-'0';
				index++;
			}
			fwrite(&ch,1,1,fout);
		}

		printf("file chunk %d decrypted,%d chunk(s) remain...\n",
				count+1,k-count-1);
		count++;
	}
	fclose(fin);
	fclose(fout);
	printf("done!\n");
	return 0;
}

