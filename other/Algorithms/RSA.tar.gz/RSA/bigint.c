/*
MAXD the number of digits in every BigInt
BASE the BASE of the BigInt number usually 10, 16
LOG_BASE = Ceil(log(2,BASE)); for fast division operation
*/
#include"stdio.h"
#define MAXD 1500
#define BASE 10
#define LOG_BASE 4
/*The unit used as digit must have range larger than BASE*(BASE+1)*/
typedef unsigned char Int;
char char_buffer[MAXD+2];
/*The charset used to represent the number
  usually use 0123456789 or 0123456789abcdef
*/
char char_num[BASE];
/*A table denote which char is used as number*/
char char_set[256]={0};
/*initialize charset and numset
  return 1 for init success
  return 0 for init failed, using default 0123456789
*/
int init_char_set(char* s)
{
  int i;
  for(i=0;i<256;i++)char_set[i]=-1;
  i=0;
  while(s[i])
  {
    if(s[i]=='+'||s[i]=='-'||char_set[s[i]]!=-1)
      {init_char_set("0123456789");return 0;}
    char_num[i]=s[i];
    char_set[s[i]]=i;
    i++;
  }
  return 1;
}

/*fill zero*/
void empty(Int* to)
{
  int i;
  for(i=0;i<=MAXD;i++)
    to[i]=0;
}

/*MOV to,from*/
void mov(Int* to,Int* from)
{
  int i;
  for(i=0;i<=MAXD;i++)
    to[i]=from[i];
}

/*NEG to*/
void neg(Int* to)
{
  Int* end=(to+MAXD);
  while(to<=end&&!(*to))to++;
  if(to<=end)(*to)=BASE-(*to);
  to++;
  while(to<=end)
    (*to++)=(BASE-1)-(*to);
}

/*INC to, return overflow flag*/
int inc(Int* to)
{
  int i;
  Int c=1;/*carry*/
  for(i=0;i<=MAXD||c;i++)
  {
    to[i]+=c;
    if(c=(to[i]>=BASE))
      to[i]-=BASE;
  }
  return c;
}


/*SGN to, return 0 for value is 0, otherwise return 1 for to>0, -1 for to<0*/
int sgn(Int* to)
{
  int i;
  int flag=1;
  if(to[MAXD]) flag=-1;
  i=MAXD;
  while(i>=0&&!to[i])i--;
  return (i>=0)*flag;
}

/*read an Int from a string start from s, return pointor after reading*/
char* readInt_s(Int* to,char* s)
{
  char *p=s,*t;
  int nf=0,i;
  while(*p==' ')p++;
  if(*p=='-')
  {
    p++;
    nf=1;
  }
  else if(*p=='+')
    p++;
  s=p;
  while(char_set[*p]!=-1)p++;
  t=p--;
  empty(to);
  for(i=0;p>=s;i++,p--)
    to[i]=char_set[*p];
  if(nf)neg(to);
  return t;
}

/*read an Int from stdin, return last char after reading*/
char readInt(Int *to)
{
  char c;
  int nf=0,i=0,j=0;
  while((c=getchar())==' ');
  if(c=='-')
  {
    nf=1;
    c=getchar();
  }
  else if(c=='+')
    c=getchar();
  while(char_set[c]!=-1)
  {
    char_buffer[i++]=c;
    c=getchar();
  }
  empty(to);
  for(i--;i>=0;i--)
    to[j++]=char_set[char_buffer[i]];
  if(nf)neg(to);
  return c;
}

/*fill a real int into Int*/
void fillint(Int* to,int num)
{
  int f=0;
  Int *temp=to;
  empty(to);
  if(num<0){f=1;num=-num;}
  while(num)
  {
    (*temp)=num%BASE;
    num/=BASE;
    temp++;
  }
  if(f) neg(to);
}

/*ADD to,from (return carry)*/
Int add(Int* to,Int* from)
{
  int i;
  Int c=0;/*carry*/
  for(i=0;i<=MAXD;i++)
  {
    to[i]+=from[i]+c;
    if(c=(to[i]>=BASE))
      to[i]-=BASE;
  }
  return c;
}

/*SUB to,from (return carry)*/
Int sub(Int* to,Int* from)
{
  int i;
  Int c;
  neg(from);
  c=add(to,from);
  neg(from);
  return (c&&!to[MAXD])||(!c&&to[MAXD]);
}

Int dec(Int to[]){
	Int ONE[MAXD+1];
	fillint(ONE,1);
	return sub(to,ONE);
}
/* test if from==to)*/
int compare(Int* from,Int* to){
	Int a[MAXD+1];
	Int b[MAXD+1];

	mov(a,from);
	mov(b,to);
	sub(a,b);
	return sgn(a);
}

/*MUL a,b (store in to)*/
void mul(Int* to,Int* a,Int* b)
{
  int i,j,k;
  int fa=0,fb=0;
  Int c;
  empty(to);
  /*draw sign out*/
  if(a[MAXD])
  {
    fa=1;
    neg(a);
  }
  if(b[MAXD])
  {
    fb=1;
    neg(b);
  }
  for(i=0;i<MAXD;i++)
  {
    if(a[i])
      for(j=0;i+j<MAXD;j++)
        if(b[j])
        {
          c=a[i]*b[j];
          k=i+j;
          while(k<MAXD&&c)
          {
            to[k]+=c;
            c=to[k]/BASE;
            to[k]%=BASE;
            k++;
          }
        }
  }
  if(fa+fb==1)neg(to);
  if(fa)neg(a);
  if(fb)neg(b);
}
 
/*remainder of the division*/
Int Rem[MAXD+1];
/*trying divider 1,2,4,8,...*/
Int Try[LOG_BASE][MAXD+1];
/*check if i*BASE^p less than Rem,max is the highest digit that scanned*/
int check(Int* i,int p,int max)
{
  int a=max+1;
  while((a-p)>=0&&Rem[a]==i[a-p])a--;
  if((a-p)<0)return 1;
  return Rem[a]>i[a-p];
}
/*reduce i*BASE^p from Rem,max is the highest digit that scanned*/
void reduce(Int* i,int p,int max)
{
  int a=0;
  Int c=0;
  for(a=0;a<=max-p;a++)
  {
    if(Rem[a+p]>=i[a]+c)
    {
      Rem[a+p]-=i[a]+c;
      c=0;
    }
    else
    {
      Rem[a+p]+=BASE-i[a]-c;
      c=1;
    }
  }
}

/*DIV a/b (Result in to,remainder in Rem,return true for divide by 0)*/
int div(Int* to,Int* a,Int* b)
{
  int i,j,k;
  int fa=0,fb=0;
  int pa,pb;
  empty(to);
  mov(Rem,a);
  /*draw sign out*/
  if(a[MAXD])
  {
    fa=1;
    neg(Rem);
  }
  mov(Try[0],b);
  if(b[MAXD])
  {
    fb=1;
    neg(Try[0]);
  }
  /*div code here*/
  pa=pb=MAXD;
  while(!Rem[pa]&&pa>=0)pa--;
  while(!Try[0][pb]&&pb>=0)pb--;
  if(pa<0||pb<0)
  {
    empty(Rem);
    return pb<0;
  }
  j=pa-pb;
  for(i=1;i<LOG_BASE;i++)
  {
    mov(Try[i],Try[i-1]);
    add(Try[i],Try[i-1]);
  }
  while(j>=0)
  {
    for(i=LOG_BASE-1;i>=0;i--)
    {
      if((1<<i)+to[j]<BASE)
      if(check(Try[i],j,pa))
      {
        to[j]+=1<<i;
        reduce(Try[i],j,pa);
      }
    }
    j--;
  }
  /*div end*/
  if(fa+fb==1)
    neg(to);
  if(fa)
    neg(Rem);
  return 0;
}
 
/*show Int based BASE*/
void show(Int* to)
{
  int f=0,i=MAXD-1;
  if(to[MAXD])
  {
    f=1;
    neg(to);
    printf("-");
  }
  while(i>0&&!to[i])i--;
  while(i>=0)
    putchar(char_num[to[i--]]);
  if(f) neg(to);
}

/* convert Int to char[] */
void to_char_array(Int* to,char res[])
{
  int f=0,i=MAXD-1;
  int index=0;
  if(to[MAXD])
  {
    f=1;
    neg(to);
    res[index++]='-';
  }
  while(i>0&&!to[i])i--;
  while(i>=0)
    res[index++]=(char_num[to[i--]]);
  if(f) neg(to);
}

/*main()
{
  int i,j,k;
  char c,o,opt[256]={0};
  Int A[MAXD+1]={0},B[MAXD+1]={0},C[MAXD+1]={0};
  init_char_set("0123456789");
  opt['-']=opt['+']=opt['*']=opt['/']=1;
Start:
  c=readInt(A);
  while(!opt[c])c=getchar();
  o=c;
  c=readInt(B);
  show(A);printf(" %c ",o);show(B);printf(" = ");
  switch(o)
  {
    case '+':
      add(A,B);
      show(A);printf("\n");
      break;
    case '-':
      sub(A,B);
      show(A);printf("\n");
      break;
    case '*':
      mul(C,A,B);
      show(C);printf("\n");
      break;
    case '/':
      i=div(C,A,B);
      if(i)
        printf("ERROR[DIV_BY_0]\n");
      else
      {
        show(C);printf(" ... ");
        show(Rem);printf("\n");
      }
      break;
  }
  goto Start;
} */
