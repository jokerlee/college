#include  <stdio.h>
#include  "bigint.h"
#include  <time.h>
/* calculate the greatest common divisor of n and m,result stored in res */
void gcd(Int n[],Int m[],Int res[]){
	Int temp[MAXD+1]={0};
	Int x[MAXD+1]={0};
	Int y[MAXD+1]={0};
	int i=-1;

	mov(x,n);
	mov(y,m);
	while (i!=0){
		div(temp,x,y);
		if (sgn(Rem)==0){ /* x | y */
			mov(res,y);
			return;
		}else{
			mov(temp,Rem);
			mov(x,y);
			mov(y,temp);
		}
	}
}

Int ext_x[MAXD+1],ext_y[MAXD+1];
void ext_euclid(Int a[],Int b[],Int res[]){
	Int t[MAXD+1];
	Int d[MAXD+1];
	Int tmp[MAXD+1];

	if (sgn(b)==0){
		fillint(ext_x,1);
		fillint(ext_y,0);
		mov(res,a);
		return;
	}
	div(tmp,a,b);
	mov(tmp,Rem);
	ext_euclid(b,tmp,res);
	mov(t,ext_x);
	mov(ext_x,ext_y);
	div(tmp,a,b);
	mov(d,tmp);
	mul(tmp,d,ext_y);
	mov(d,tmp);
	mov(tmp,t);
	sub(tmp,d);
	mov(ext_y,tmp);
}

/* calculate (n^x)%m,result stored in res */
void fast_mod(Int n[],Int x[],Int m[],Int res[]){
	Int b[MAXD+1]={0};
	Int TWO[MAXD+1]={0};
	Int temp[MAXD+1]={0};
	Int N[MAXD+1]={0};
	Int M[MAXD+1]={0};
	Int X[MAXD+1]={0};

	fillint(b,1);/* b=1 */
	fillint(TWO,2);/* TWO=2 */
	mov(N,n);
	mov(M,m);
	mov(X,x);

	while (sgn(X)!=0){ /* while x!=0 */
		div(temp,X,TWO);
		if (sgn(Rem)!=0){ /* if (x%2)!=0 */
			/* b=(b*n)%m */
			mul(temp,N,b);
			mov(b,temp);
			div(temp,b,M);
			mov(b,Rem);
		}
		/* n=(n^2)%m */
		mul(temp,N,N);
		mov(N,temp);
		div(temp,N,M);
		mov(N,Rem);

		/* x/=2 */
		div(temp,X,TWO);
		mov(X,temp);
	}
	mov(res,b);
	return;
}

/* WITNESS function in the rabbin_miller */
int witness(Int a[],Int n[]){
	int i=0,k=0,t=0;
	Int j[MAXD+1];
	Int x[MAXD+1],tmp[MAXD+1],tmp2[MAXD+1];
	Int temp[MAXD+1];
	Int ONE[MAXD+1];
	Int TWO[MAXD+1];
	Int ZERO[MAXD+1];
	Int A[MAXD+1];
	Int N[MAXD+1];
	
	fillint(TWO,2);
	fillint(ONE,1);
	fillint(ZERO,0);
	mov(A,a);
	mov(N,n);

	mov(j,n);
	dec(j);

	div(tmp,j,TWO);
	while (compare(Rem,ZERO)==0){
		div(tmp,j,TWO);
		mov(j,tmp);
		t++;
		div(tmp,j,TWO);
	}
	fast_mod(A,j,N,x);

	mov(tmp2,n);
	dec(tmp2);
	for (i=1;i<=t;i++){
		/* tmp=x*x%n */
		mul(tmp,x,x);
		div(temp,tmp,N);
		mov(tmp,Rem);

		if (compare(tmp,ONE)==0 && compare(x,ONE)!=0 &&
				compare(x,tmp2)!=0)
			return 1;
		mov(x,tmp);
	}
	if (compare(x,ONE)!=0)
		return 1;
	return 0;

}

/* generate a random Int that has n decimal digit */
void random(Int to[],int n){
	int i=0,j=0,k=0;
	char buff[MAXD]={0};

	srand(time(NULL));

	while (buff[0]==0)
		buff[0]=rand()%10+'0';
	for (i=1;i<=n-1;i++){
		buff[i]=rand()%10+'0';
	}
	readInt_s(to,buff);
	return;
}

int miller_rabbin(Int n[]){
	int i=0,j=0,k=0;
	Int a[MAXD+1];
	Int r[MAXD+1];
	Int tmp[MAXD+1];

	Int ONE[MAXD+1];
	Int TWO[MAXD+1];
	Int ZERO[MAXD+1];

	fillint(ONE,1);
	fillint(TWO,2);
	fillint(ZERO,0);

	random(r,700);
	div(tmp,r,n);
	mov(a,Rem);
	inc(a);

	div(tmp,n,TWO);
	if (compare(Rem,ZERO)==0 && compare(n,TWO)!=0){
		return 0;
	}

	if (compare(n,TWO)==0)
		return 1;

	for (i=1;i<=5;i++){
		inc(a);
		div(tmp,a,n);
		mov(a,Rem);
		inc(a);
		
		div(tmp,n,a);
		if (compare(Rem,ZERO)==0){
			i--;
			continue;
		}
		if (witness(a,n))
			return 0;
	}
	return 1;
}

