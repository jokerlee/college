#include  <stdio.h>
#include  "bigint.h"
#include  "basic_algorithm.h"
int main(int argc, char *argv[])
{
	int i,j,k;
	Int n[MAXD+1],m[MAXD+1],res[MAXD+1];
	Int x[MAXD+1];
	char opt[256]={0};
	
	/* initialize */
	init_char_set("0123456789");
	opt['-']=opt['+']=opt['*']=opt['/']=1;

	/*readInt(n);
	readInt(x);
	readInt(m);

	fast_mod(n,x,m,res);
	show(n);
	printf(" ^ ");
	show(x);
	printf(" %% ");
	show(m);
	printf(" = ");
	show(res);
	printf("\n");*/
		random(n,300);
		while (miller_rabbin(n)==0){
			inc(n);
		}
			show(n);
			printf("\n");
	return 0;
}
