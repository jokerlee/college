var byrMain = null;

function prefillInfo() {
    var infos = window.arguments[0];
    byrMain = window.arguments[1];
    var obj = document.getElementById("alertTextBox");
    for (var i=0; i<infos.length; ++i){
        var em = document.createElement("label");
        var text = "(关键字\""+infos[i][3]+"\")"+infos[i][0]+" : "+infos[i][1];
        em.setAttribute("value", text);
        em.setAttribute("class", "alertText plain");
        em.setAttribute("onclick", "byrMain.openPage(\""+infos[i][2]+"\")");
        obj.appendChild(em);
    }
    infos.splice(0, infos.length);
}
    
