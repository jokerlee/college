/*
 *
 *
 * */

const gMenuCount = 4;
const gDelay = 5;
const gFrameUrl = "http://forum.byr.edu.cn/wForum/default.php";
const gIndexUrl = "http://forum.byr.edu.cn/wForum/index.php";
const gBoardUrl = "http://forum.byr.edu.cn/wForum/board.php?name=";
const gUrlPrefix = "http://forum.byr.edu.cn/wForum/rss.php?board=";
const gUrlTopten = "http://forum.byr.edu.cn/wForum/rsstopten.php";
const gUrlBT = "http://bt.byr.edu.cn/rss.php?passkey=aa";


function byr_ui() {
	this.newItems = new Array();
    this.matchedItems = new Array();

}

byr_ui.prototype.onload = function() {
	if (document.getElementById("status-bar")) {
		gPrefs.init();
		gBYR_BT.init();  
		gBYR_UI.setRootMenu();
        window.setTimeout(gBYR_UI.refreshInfo, gDelay*1000);
	    window.setInterval(gBYR_UI.refreshInfo, gPrefs.pref["refresh_duration"]*1000);
	}
}

byr_ui.prototype.onunload = function() {
	if (document.getElementById("status-bar")) {
		gPrefs.saveAllPrefs();
	}
}

byr_ui.prototype.onPreferences = function() {
	gPrefs.saveAllPrefs();
    window.showModalDialog("chrome://byrforumbt/content/prefdialog.xul", "", "centerscreen");
	gPrefs.loadAllPrefs();
	this.setRootMenu();
    this.refreshInfo();
}

byr_ui.prototype.refreshBT = function() {
    var obj = document.getElementById("menu-main");
    obj.setAttribute("tooltiptext", gBYR_BT.btInfo);
}

byr_ui.prototype.refreshInfo = function() {
	gBYR_UI.setAllSubMenus();
    if (gPrefs.pref["enable_bt"] == true) {
        gBYR_BT.fetchState();
	    window.setTimeout(gBYR_UI.refreshBT, gDelay*1000);
	} else
        document.getElementById("menu-main").setAttribute("tooltiptext", "");
	
    if (gPrefs.pref["enable_alert"] == true)
        window.setTimeout(gBYR_UI.checkNewItems, gDelay*1000);
}

byr_ui.prototype.checkNewItems = function() {
    if (gBYR_UI.newItems.length > 0) {
        window.openDialog("chrome://byrforumbt/content/alert.xul","_blank",
            "chrome,dialog=yes,titlebar=no,popup=yes",
            gBYR_UI.newItems, gBYR_UI).focus();
    }

    if (gBYR_UI.matchedItems.length > 0) {
        window.openDialog("chrome://byrforumbt/content/alertmatch.xul","_blank",
            "chrome,dialog=yes,alwaysRaised=yes",
            gBYR_UI.matchedItems, gBYR_UI).focus();
    }
}

byr_ui.prototype.onReplyHelper = function() {
    window.openDialog("chrome://byrforumbt/content/replyhelper.xul","_blank",
        "chrome,dialog=yes,alwaysRaised=yes",
        getBrowser()).focus();
}

byr_ui.prototype.setAllRead = function() {
    var boards = gPrefs.boards.names;
    for (var i=0; boards && i<boards.length; ++i) {
        var menu = document.getElementById(boards[i]);
        for (var j=0; j<menu.childNodes.length; ++j) {
            gBYR_UI.setItemRead(menu.childNodes[j]);
        }
    }
}

byr_ui.prototype.onClickIcon = function() {
    document.getElementById("menu-root").showPopup(
        document.getElementById("menu-main"), 
        -1, -1, "popup", "topleft", "bottomleft"
    );
}

byr_ui.prototype.clearMenu = function(board) {
	var node = document.getElementById(board);
	for (var i=node.childNodes.length-1; i>=0; --i)
		node.removeChild(node.childNodes[i]);
}

byr_ui.prototype.setRootMenu = function() {
	var root = document.getElementById("menu-root");
	while (root.childNodes.length > gMenuCount) {
		root.removeChild(root.firstChild);
	}
	var list = gPrefs.boards.names;
	if (list.length > 0) {
		var point = document.createElement("menuseparator");
		root.insertBefore(point, root.firstChild);
		var menu, popup, url;
		for (var i=0; i<list.length; ++i) {
			menu = document.createElement("menu");
			popup = document.createElement("menupopup");
			popup.setAttribute("id", list[i]);
			with (menu) {
				setAttribute("id", "menu-"+list[i]);
				setAttribute("label", gPrefs.getString(list[i]));
				setAttribute("class", "menu-iconic");
				setAttribute("image", "chrome://byrforumbt/skin/rss-new.png");
                if (list[i] != "topten" && list[i] != "hottorrent") {
                    if (list[i] == "newtorrent") url = "http://bt.byr.edu.cn/listtorrent.php";
                    else url = gBoardUrl + list[i];
                    setAttribute("ondblclick", 'gBYR_UI.openPage(\"'+url+'\")');
                }
				appendChild(popup);
			}
			root.insertBefore(menu, point);
		}
	}
}

byr_ui.prototype.setAllSubMenus = function() {
	for (var i=0; i<gPrefs.boards.names.length; ++i) {
		var board = gPrefs.boards.names[i];
		if (board == "hottorrent") gBYR_BT.fetchHotTorrents();	    
		else gBYR_UI.setSubMenu(board);
	}
}

byr_ui.prototype.setSubMenu = function(board) {
	var root = document.getElementById(board);
	var rqst = new XMLHttpRequest();
	var newestid = gPrefs.boards.infoids[findFeededBoard(board)];
	var maxid = newestid;
    var patterns = gPrefs.boards.filters[findFeededBoard(board)];
	var listlen = gPrefs.pref["list_length"];
	if (board == "topten") rqst.open("GET", gUrlTopten, true);
	else if (board == "newtorrent") rqst.open("GET", gUrlBT, true);
	else rqst.open("GET", gUrlPrefix+board+"&ic=1", true);

	rqst.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var obj = this.responseXML.getElementsByTagName("item");
			var point = null;
			if (root.hasChildNodes()) point = root.firstChild;
			var title, link, node, content, infoid;
			for (var i=0; i<obj.length && root.childNodes.length<listlen; ++i) {
				if (board == "newtorrent")
					link = obj[i].getElementsByTagName("guid")[0].childNodes[0].nodeValue; 
				else
				    link = obj[i].getElementsByTagName("comments")[0].childNodes[0].nodeValue;

				infoid = getInfoId(link);
				if (infoid == newestid && root.childNodes.length == listlen)	break;

				node = document.createElement("menuitem");
				title = obj[i].getElementsByTagName("title")[0].childNodes[0].nodeValue;
				if (board != "topten") {
					content = obj[i].getElementsByTagName("description")[0].childNodes[0].data;
					content = content.replace(new RegExp("<br\/>", "gm"), '\n');
					node.setAttribute("tooltiptext", content);
				}

				with (node) {
					setAttribute("label", title);
					setAttribute("class", "menuitem-iconic");
					setAttribute("infoid", infoid);
					setAttribute("oncommand", 'gBYR_UI.openPage(\"'+link+'\");'
                                            + 'gBYR_UI.setItemRead(this);');
				}	
				if (infoid > newestid) {
					if (board != "topten") gBYR_UI.newItems.push([gPrefs.getString(board), title, link]);
					node.setAttribute("style", "font-weight:bold");
					node.setAttribute("image", "chrome://byrforumbt/skin/item-new.png");
                    var key;
                    if ((key = gBYR_UI.findMatched(patterns, title+content)) != null) {
                        gBYR_UI.matchedItems.push([gPrefs.getString(board), title, link, key]); 
                    }
                    if (infoid > maxid) maxid = infoid;
                } else {
					node.setAttribute("image", "chrome://byrforumbt/skin/item-old.png");
                }

				if (point != null) {
					root.removeChild(root.lastChild);
					root.insertBefore(node, point);
				} else {
					root.appendChild(node);
				}
			}
			gPrefs.boards.infoids[(findFeededBoard(board))] = maxid;
		}
	}
	rqst.send(null);
}

byr_ui.prototype.findMatched = function(patterns, main) {
    if (patterns == "") return null;
    list = patterns.split(";");
    for (var i=0; i<list.length; ++i) {
        if (main.indexOf(list[i]) != -1) {
            return list[i];
        }
    }
    return null;
}

byr_ui.prototype.setItemRead = function(node) {
    node.setAttribute("style", "font-weight:normal");
	node.setAttribute("image", "chrome://byrforumbt/skin/item-old.png");
}

byr_ui.prototype.openPage = function(url) {
    if (url.indexOf("http://bt.byr.edu.cn/") != -1) {
        var browser = getBrowser();
        browser.selectedTab = browser.addTab(url);
    } else {
        var newtab = gBrowser.addTab(gFrameUrl);
        gBrowser.selectedTab = newtab;;
	    var newTabBrowser = gBrowser.getBrowserForTab(newtab);
	    var func;
	    var count = 1;
	    newTabBrowser.addEventListener("DOMContentLoaded", func = function(event) { 
		    curl = event.originalTarget.location.toString()
		    if (curl == gIndexUrl && count++ == 1)
			    event.originalTarget.location.replace(url);
	    }, false);
	}
}

var gBYR_UI = new byr_ui();

window.addEventListener("load", gBYR_UI.onload, false);
window.addEventListener("unload", gBYR_UI.onunload, false);
