
function initBoardList() {
    gPrefs.init();
    var list = this.document.getElementById("listchildren");
    var boards = gPrefs.boards.names;
    for (var i=0; i<boards.length; ++i) {
        list.appendChild(createRow(boards[i], gPrefs.boards.filters[i]));
    }
}

function createRow(board, filter) {
    var item = this.document.createElement("treeitem");
    var row = this.document.createElement("treerow");
    
    var cell1 = this.document.createElement("treecell");
    cell1.setAttribute("value", board);
    cell1.setAttribute("label", gPrefs.getString(board));
    cell1.setAttribute("editable", "false");
    var cell2 = this.document.createElement("treecell");
    cell2.setAttribute("label", filter);
    row.appendChild(cell1);
    row.appendChild(cell2);
    item.appendChild(row);
    return item;
}

function onAccountSetting() {
    window.showModalDialog("accountdialog.xul");
}

function onAddItem() {
    var tree = this.document.getElementById("boardtree");
    var item = tree.view.getItemAtIndex(tree.currentIndex);
    if (item.firstChild.nextSibling == null) { // leaf node
        item = item.firstChild.firstChild;
        var list = this.document.getElementById("listchildren");
        var board = item.getAttribute("id");
        if (gPrefs.findFeededBoard(board) == -1) {
            list.appendChild(createRow(board, ""));
            gPrefs.addBoard(board);
        }
    }
}

function onRemoveItem() {
    var tree = document.getElementById("boardlist");
    var idx = tree.currentIndex;
    if (idx != -1) {
        var list = document.getElementById("listchildren");
        var item = list.childNodes[idx];
        gPrefs.removeBoard(item.firstChild.firstChild.getAttribute("value"));
        list.removeChild(item);
        tree.currentIndex = (idx-1>0)?(idx-1):(0);
        if (tree.view.rowCount == 0) tree.currentIndex = -1;
    }
}

function onMoveUpItem() {
    var tree = document.getElementById("boardlist");
    var idx = tree.currentIndex;
    if (idx > 0) {
        var list = document.getElementById("listchildren");
        var crnt = list.childNodes[idx];
        var above = crnt.previousSibling;
        swapNode(crnt, above);
        tree.currentIndex = idx-1;
        gPrefs.swapTwoBoards(crnt.firstChild.firstChild.getAttribute("value"), 
                             above.firstChild.firstChild.getAttribute("value") );
    }
}

function onMoveDownItem() {
    var tree = document.getElementById("boardlist");
    var idx = tree.currentIndex;
    if (idx != -1 && idx != tree.view.rowCount-1) {
        var list = document.getElementById("listchildren");
        var crnt = list.childNodes[idx];
        var below = crnt.nextSibling;
        swapNode(crnt, below);
        tree.currentIndex = idx+1;
        gPrefs.swapTwoBoards(crnt.firstChild.firstChild.getAttribute("value"), 
                             below.firstChild.firstChild.getAttribute("value") );
    }
}

function swapNode(node1, node2) {
    if (!node1 && !node2) return null;
    var parent = node1.parentNode;
    var t1 = node1.nextSibling;
    var t2 = node2.nextSibling;
    if (t1) parent.insertBefore(node2, t1);
    else parent.appendChild(node2);
    if (t2) parent.insertBefore(node1, t2);
    else parent.appendChild(node1);
}

function onAccept() {
    var list = document.getElementById("listchildren").childNodes;
    for (var i=0; i<list.length; ++i) {
        var cell = list[i].firstChild.lastChild;
        var pattern = list[i].firstChild.lastChild.getAttribute("label");
        pattern.replace(/,/g, ";");
        gPrefs.boards.filters[i] = pattern; 
    }
    gPrefs.saveAllPrefs();
}
