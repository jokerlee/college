function onChecked() {
    var checked = document.getElementById("btEnable").hasAttribute("checked");
    document.getElementById("btUser").disabled = !checked;
    document.getElementById("btPasswd").disabled = !checked;
}
