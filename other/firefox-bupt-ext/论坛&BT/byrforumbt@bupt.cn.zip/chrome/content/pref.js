
var gPrefs = {
    _prefs : null,  
    pref : new Object(),
    boards: new Object(),
    _allPrefs : new Array
    ( 
        //["feeded_boards", "Char"],
        //["board_filters", "Char"],
        //["newest_ids", "Char"],
        ["list_length", "Int"],
        ["refresh_duration", "Int"],
        ["enable_alert", "Bool"],
        ["enable_bt", "Bool"],
        ["username", "Char"],
        ["password", "Char"]
    ),

    init : function() {
        gPrefs._prefs = Components.classes["@mozilla.org/preferences;1"]
            .getService(Components.interfaces.nsIPrefService)
            .getBranch("extensions.byrforumbt.");
        gPrefs._prefs.QueryInterface(Components.interfaces.nsIPrefBranch2);
        gPrefs.loadAllPrefs();
    },    

    getBoardPrefs : function() {
        gPrefs.boards = new Object();
        gPrefs.boards["names"]   = string2Array(gPrefs._prefs.getCharPref("feeded_boards"));
        gPrefs.boards["infoids"] = string2Array(gPrefs._prefs.getCharPref("newest_ids"));
        var unescaped = unescape(gPrefs._prefs.getCharPref("board_filters"));
        gPrefs.boards["filters"] = string2Array(unescaped);

    },
    
    setBoardPrefs : function() {
        gPrefs._prefs.setCharPref("feeded_boards", array2String(gPrefs.boards.names));
        gPrefs._prefs.setCharPref("newest_ids", array2String(gPrefs.boards.infoids));
        var escaped = escape(array2String(gPrefs.boards.filters));
        gPrefs._prefs.setCharPref("board_filters", escaped);

    },

    saveAllPrefs : function() {
        gPrefs.setBoardPrefs();
        /* no use now, use prefpane instead
        var name, value, type; 
        for (var i=0; i<gPrefs._allPrefs.length; ++i) { 
            name = gPrefs._allPrefs[i][0];
            value = gPrefs.pref[name];
            type = gPrefs._allPrefs[i][1];
            eval('gPrefs._prefs.set'+type +'Pref("'+name+'","'+value +'");');
        }*/
    },

    loadAllPrefs : function() {
        gPrefs.getBoardPrefs();
        var name, value, type;
        for (var i=0; i<gPrefs._allPrefs.length; ++i) {
            name = gPrefs._allPrefs[i][0];
            type = gPrefs._allPrefs[i][1];
            eval('gPrefs.pref[name] = gPrefs._prefs.get' + type + 'Pref("' + name + '");');
        }
    },

    getString : function(name) {
        var src = "chrome://byrforumbt/locale/boards.properties";
        var bundle = Components.classes["@mozilla.org/intl/stringbundle;1"]
            .getService(Components.interfaces.nsIStringBundleService)
            .createBundle(src);
        return bundle.GetStringFromName(name);
    },

    swapTwoBoards : function(board1, board2) {
        var idx1 = gPrefs.findFeededBoard(board1);
        var idx2 = gPrefs.findFeededBoard(board2);
        swapArrayElements(gPrefs.boards.names, idx1, idx2);
        swapArrayElements(gPrefs.boards.infoids, idx1, idx2);
        swapArrayElements(gPrefs.boards.filters, idx1, idx2);
    },

    addBoard : function(board) {
        gPrefs.boards.names.push(board);
        gPrefs.boards.infoids.push("0");
        gPrefs.boards.filters.push("");
    },

    removeBoard : function(board) {
        var idx = gPrefs.findFeededBoard(board);
        removeArrayElement(gPrefs.boards.names, idx);
        removeArrayElement(gPrefs.boards.infoids, idx);
        removeArrayElement(gPrefs.boards.filters, idx);
    },

    findFeededBoard : function(board) {
        for (var i=0; i<gPrefs.boards.names.length; ++i)
            if (gPrefs.boards.names[i] == board)
                return i;
        return -1;
    }
};


function removeArrayElement(ary, dx) {
    if (isNaN(dx) || dx>=ary.length || dx<0)
        return null;
    for (var i=dx; i<ary.length-1; i++)
        ary[i] = ary[i+1];
    ary.pop();
}

function swapArrayElements(ary, dx1, dx2) {
    if (isNaN(dx1) || dx1>ary.length || dx1<0 || 
        isNaN(dx2) || dx2>ary.length || dx2<0 )
        return null;
    var tmp = ary[dx1];
    ary[dx1] = ary[dx2];
    ary[dx2] = tmp;
}

function string2Array(str) {	
    var j = str.indexOf(",");
    var ary = new Array();
    for (var i=0; j!=-1; ) {
        ary.push(str.substring(i, j));
        i = j + 1;
        j = str.indexOf(",", i);
    }
    return ary;
}

function array2String(ary) {
	if (ary.length > 0)	return (ary.toString() + ",");
	else return "";
}

function getInfoId(str) {
	return str.substr(str.lastIndexOf("=")+1, str.length-1);
}

function findFeededBoard(board) {
    for (var i=0; i<gPrefs.boards.names.length; ++i)
        if (gPrefs.boards.names[i] == board)
            return i;
    return -1;
}

/*
do not use Array.prototype, it will cause an boring bug, see contents at the url below
https://bugzilla.mozilla.org/show_bug.cgi?id=404124
*/
