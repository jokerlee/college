const loginURL = "http://bt.byr.edu.cn/takelogin.php";

function byr_bt() {
    this.state = false;
    this.btInfo = null;
    this.username = null;
    this.password = null;
}

byr_bt.prototype.init = function() {
    gBYR_BT.username = gPrefs.pref["username"];
    gBYR_BT.password = gPrefs.pref["password"];
    if (gBYR_BT.username != "") {
        gBYR_BT.btInfo = gPrefs.getString("no-account");
        gBYR_BT.login();
    }
}

byr_bt.prototype.login = function() {
    var account = [["username", this.username],["passwd", this.password]];
    var rqst = new XMLHttpRequest();
    gBYR_BT.btInfo = gPrefs.getString("login-in-progress"); //将登录状态设置为验证登录中...
	rqst.overrideMimeType("text/html; charset=utf8");		
	var args = "&" + account[0][0] + "=" + encodeURIComponent(account[0][1]) + 
	            "&" + encodeURIComponent(account[1][0]) + "=" + encodeURIComponent(account[1][1]);
	rqst.open("post", loginURL);
	rqst.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	rqst.setRequestHeader("Content-Length", args.length);
	
	rqst.onreadystatechange = function() {
		if (rqst.readyState == 4) {
			var text = rqst.responseText;
			var regex = new RegExp("logout", "g"); //检查返回的字符串有没有包含"infoList"
			var result = regex.exec(text);
			if (result != null) {              //包含"logout"证明跳转到了成功页面，登陆状态变为登陆成功!
			    gBYR_BT.state = true;
			    gBYR_BT.btInfo = gPrefs.getString("login-success");
			} else {            //不包含"logout"证明出现了错误，登陆状态变为登陆失败！
			    gBYR_BT.state = false;        
			    gBYR_BT.btInfo = gPrefs.getString("login-fail");
			}
		}
	}
	rqst.send(args);
}

byr_bt.prototype.fetchHotTorrents = function() {
	var aURL = "http://bt.byr.edu.cn/";
    var req = new XMLHttpRequest();
    var i = 0;
    var result;
	req.open("GET", aURL, true);
	req.onreadystatechange = function() {
		if (req.readyState == 4 && req.status == 200) {
			var text = req.responseText;
			var regex = /.*target=\'_blank\'>(.*)&nbsp(.*)<\/a><\/li>/gm;
			var items = text.match(regex);
			var time, title, url, list = new Array();
			for (var i=10; i<20; ++i) {
                url = items[i].match(/href=\'(.*)\' target/)[1];
                time = items[i].match(/_blank\'\>(.*)&/)[1];
                title = items[i].match(/nbsp(.*)\<\/a\>/)[1];
                list.push([url, time, title]);
			}
            gBYR_UI.clearMenu("hottorrent");
        	var root = document.getElementById("hottorrent");
			for (var i=0; i<gPrefs.pref["list_length"]; ++i) {
			    var node = document.createElement("menuitem");
			    with (node) {
					setAttribute("label", list[i][2]);
					setAttribute("class", "menuitem-iconic");
                    setAttribute("image", "chrome://byrforumbt/skin/item-old.png");
					setAttribute("oncommand", 'gBYR_UI.openPage(\"'+"http://bt.byr.edu.cn/"+list[i][0]+'\");'
                                            + 'gBYR_UI.setItemRead(this);');
				}
			    root.appendChild(node);
			}
		}
	}	
	req.send(null);
}
	
byr_bt.prototype.fetchState = function() {
    if (this.state == false) return;
    var aURL = "http://bt.byr.edu.cn/tools.php?action=userinfo";
    var req = new XMLHttpRequest();
    var j;
	req.open("GET", aURL, true);
	req.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var obj = this.responseText;
			var html = obj.split("\n");
			for (var i = 0; i < html.length; ++ i) {
				if (html[i].match(/Welcome,/))
					j = i;	//出现"Welcome"，说明找到上传下载信息所在行
				if (html[i].match(/id=\"userinfo\"/))		//出现'id="userinfo"'，说明找到个人资料所在的地方
					break;
			}

			html[i+1].match(/<th.*>(.*)<\/th>.*>(.*)&nbsp/g);
			var user_name = RegExp.$1 + ":" + RegExp.$2 + "\n";	//用户名

			html[i+6].match(/<th.*>(.*)<\/th>.*>(.*)&nbsp/g);
			var shareRate = RegExp.$1 + ":" + RegExp.$2 + "\n";	//共享率

			html[i+7].match(/<th.*>(.*)<\/th>.*>(.*)&nbsp/g);
			var aup_sum = RegExp.$1 + ":" + RegExp.$2 + "\n";	//实际上传流量

			html[i+8].match(/<th.*>(.*)<\/th>.*>(.*)&nbsp/g);
			var up_sum = RegExp.$1 + ":" + RegExp.$2 + "\n"; //上传流量

			html[i+9].match(/<th.*>(.*)<\/th>.*>(.*)&nbsp/g);
			var down_sum = RegExp.$1 + ":" + RegExp.$2 + "\n";	//下载流量

			html[i+10].match(/<th.*>(.*)<\/th>.*>(.*)&nbsp;(.*)<\/td>/g)
			var integral = RegExp.$1 + ":" + RegExp.$2 + " " + RegExp. $3 + "\n";	//积分
			
			html[j].match(/.*&nbsp&nbsp(.*)&nbsp&nbsp(.*)<\/a>/);
			var up_num = RegExp.$1;	// 正在上传
			var down_num = RegExp.$2;	//正在下载
			
			gBYR_BT.btInfo = user_name + shareRate + aup_sum + up_sum + down_sum + integral + up_num + "		" + down_num;
		}
	}
	req.send(null);		
}


var gBYR_BT = new byr_bt();
