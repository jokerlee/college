const gArticleUrl1 = "http://forum.byr.edu.cn/wForum/default.php";
const gArticleUrl2 = "http://forum.byr.edu.cn/wForum/disparticle";

var replyBox = {

    refBrowser : null,
    refWindow : null,
    refDoc : null,
    refTitle : null,
    refContent : null,
    titleBox : null,
    contentBox : null,
    
    init : function() {
        refBrowser = window.arguments[0];
        this.initDocument();     
        var title = refDoc.getElementsByName("subject")[0];
        var content = refDoc.getElementById("oArticleContent");
        
        titleBox = document.getElementById("edit-title");
        contentBox = document.getElementById("edit-content");
        titleBox.value = refTitle.getAttribute("value");
        contentBox.value = refContent.getAttribute("value");
        
        var x = screen.availWidth - window.outerWidth - 100;
        var y = screen.availHeight - window.outerHeight;
        window.moveTo(x, y);
    },

    initDocument : function() {
        var url = refBrowser.currentURI.spec;
        if (!url) replyBox.error();
        else if (url.indexOf(gArticleUrl1) != -1) {
            refWindow = refBrowser.contentWindow.frames[1];
            refDoc = refWindow.document;
            if (refDoc.location.toString().indexOf(gArticleUrl2) == -1)
                replyBox.error();
        }
        else if (url.indexOf(gArticleUrl2) != -1) {
            refWindow = refBrowser.contentWindow;
            refDoc = refBrowser.contentDocument;
        }
        else replyBox.error();
        
        refTitle = refDoc.getElementsByName("subject")[0];
        refContent = refDoc.getElementById("oArticleContent");
    },
    
    error : function() {
        alert("请在北邮人论坛帖子页面使用此功能");
        window.close();
    },
    
    onSubmit : function() {
        refTitle.value = titleBox.value;
        refContent.value = contentBox.value;
        refDoc.forms[0].submit();
    },

    onReset : function() {
        contentBox.value = "";
    },

    onPrev : function() {
        var url = refWindow.location.toString();
        var idx = url.indexOf("page");
        if (idx == -1) return null;
        else {
            var page = parseInt(url.substr(idx+5)) - 1;
            if (page > 0) {
                var newurl = url.substring(0, idx-1) + "&page=" + page.toString();
                refWindow.location.replace(newurl);
            }
        }
    },
    
    onNext : function() {
        var url = refWindow.location.toString();
        var idx = url.indexOf("page");
        if (idx == -1)
            refWindow.location.replace(url+"&page=2");
        else {
            var page = parseInt(url.substr(idx+5)) + 1;
            var newurl = url.substring(0, idx-1) + "&page=" + page.toString();
            refWindow.location.replace(newurl);
        }
    }
}
/*var gUrl1 = "http://forum.byr.edu.cn/wForum/default.php";
var gUrl2 = "http://forum.byr.edu.cn/wForum/disparticle";

function test() {
    var url = getBrowser().currentURI.spec;
    if (!url) return null;
    var cDoc = null;
    
    if (url.indexOf(gUrl1) != -1)
        cDoc = getBrowser().contentWindow.frames[1].document;
    else if (url.indexOf(gUrl2) != -1)
        cDoc = getBrowser().contentDocument;
    else
        return null;
    
    var title = cDoc.getElementsByName("subject")[0];
    var content = cDoc.getElementById("oArticleContent");
    content.value = "test";
    title.value = "aaa";    

    //cDoc.forms[0].submit();
}
*/

/*
window.document.addEventListener("DOMContentLoaded", function(evt) {
	if (evt.originalTarget instanceof HTMLDocument) {
	    //if (evt.originalTarget instanceof HTMLIFrame)
	        //return;
	    url = evt.originalTarget.location.toString();
	    if (url.indexOf("disparticle") != -1) {
	        alert("1");
		    gDoc = evt.originalTarget;
		}
    }
},
true);
*/

